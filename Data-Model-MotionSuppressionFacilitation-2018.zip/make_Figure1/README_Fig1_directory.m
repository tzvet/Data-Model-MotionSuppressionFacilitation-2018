% This directory contains all data and scripts that allow to reproduce Figure 1
% of the manuscript.
%
% 1. The data extracted with the help of PlotDigitizer (http://plotdigitizer.sourceforge.net)
%    from Figure 1A in Tadin & Lappin, Vision Research, 2005
%    "extracted_data_TadinLappin_Fig1.txt.csv"
%    "data_tadinlappin.txt"
% 2. The scripts for the model developed in the manuscript
%    a. "fit_plot_data_tadinlappin.m" - for fitting Tadin & Lappin's data
%    b. "Figure1_tzvetanov.m" - make Figure 1
%