%
% Figure 1: data Tadin & Lappin 2005 + Model description
% 

clear all;

a = reshape( load('data_tadinlappin.txt'), [8,4,2] );
load model_fit_TadinLappin2005.mat;

sizestim = a(:,:,1);
dur_thr = a(:,:,2);
contr = repmat( [0.09,0.2,0.42,0.92], [8,1] );

plchng = [-0.06,-0.04,0.08,0.08];% [-0.04,-0.00,0.08,0.08];

figure(1); clf; fs = 14; lw=2; ms=8;

subplot(1,3,1)
ii=1; loglog( sizestim(:,ii), dur_thr(:,ii), 'kd', 'markerfacecolor', 'w', 'markersize', ms, 'linewidth', lw )
hold on;
ii=2; loglog( sizestim(:,ii), dur_thr(:,ii), 'kd', 'markerfacecolor', 'k', 'markersize', ms, 'linewidth', lw )
ii=3; loglog( sizestim(:,ii), dur_thr(:,ii), 'ko', 'markerfacecolor', 'w', 'markersize', ms, 'linewidth', lw )
ii=4; loglog( sizestim(:,ii), dur_thr(:,ii), 'ko', 'markerfacecolor', 'k', 'markersize', ms, 'linewidth', lw )
hold off;
set(gca,'fontsize',fs,'position',get(gca,'position')+plchng);
axis([0.2,10,10,300]); axis square; box off;
xlabel('Stimulus size (deg.)')
ylabel('Duration Threshold (ms)')
hl=legend({'c=9%';'c=20%';'c=42%';'c=92%'},'location','north');
set(hl,'fontsize',fs-4,'box','off','position',get(hl,'position')+[0,-0.225,0,0])
text(0.25,300,'A','fontsize',fs*1.5,'fontweight','bold')

sizestimth = repmat( (0.25:0.05:6.5)', [1,4] );
contrth = repmat( [0.09,0.2,0.42,0.92], [numel(sizestimth(:,1)),1] );
thr_model=[]; thr_model = Model_TadinLAppin_c50_DurThresh( contrth, sizestimth, pf );

hold on; lt = {'-';'--';'-.';':'};
for ii=1:4, loglog( sizestimth(:,1), thr_model(:,ii), ['k' lt{ii}], 'linewidth', 1 ); end
hold off;


subplot(1,3,2)
s = -9:0.1:9;
re = 1/sqrt(2*pi)/pf(4) * exp(-0.5*(s/pf(4)).^2);
ri = 1/sqrt(2*pi)/pf(5) * exp(-0.5*(s/pf(5)).^2);
stimsize = -2:0.1:2;
restim = 1/sqrt(2*pi)/pf(4) * exp(-0.5*(stimsize/pf(4)).^2);
ristim = 1/sqrt(2*pi)/pf(5) * exp(-0.5*(stimsize/pf(5)).^2);

fill( [stimsize,fliplr(stimsize)], [restim,zeros(size(restim))], [1,0.5,0.5], 'edgecolor','none' );
hold on;
fill( [stimsize,fliplr(stimsize)], [-ristim,zeros(size(ristim))], [0.5,0.5,1], 'edgecolor','none' );
plot( s,re,'r-','linewidth',lw, s,-ri,'b-','linewidth',lw )
line([s(1),s(end)],[0,0],'color','k')
hold off;
set(gca,'fontsize',fs,'xtick',-8:4:8,'ytick',-0.1:0.1:0.1,'position',get(gca,'position')+plchng+[0.04,0,0,0]);
axis([s(1),s(end),-0.2,0.2]); axis square; box off;
xlabel({'Distance from receptive';'field centre (deg.)'})
ylabel('Response')
text(-8,0.2,'B','fontsize',fs*1.5,'fontweight','bold')



subplot(1,3,3)
c= 10.^(-3:0.1:0);
modelCtr = @(c,p,c12) ( c.^p*(1-c12^p) ./ ( c.^p*(1-2*c12^p) + c12.^p ) );
rce = modelCtr( c, pf(8), pf(6) );
rci = modelCtr( c, pf(8), pf(7) );
semilogx( c, rce, 'r-', 'linewidth', lw, c, rci, 'b-', 'linewidth', lw);
set(gca,'fontsize',fs,'position',get(gca,'position')+plchng+[0.06,0,0,0],'ytick',[0,1]);
axis([c(1),c(end),0,1.05]); axis square; box off;
xlabel('Stimulus contrast')
%ylabel('Response')
text(0.0015,1.05,'C','fontsize',fs*1.5,'fontweight','bold')


return;

orient landscape
print('-dpdf','Figure1_tzvetanov.pdf')
print('-dpng','-r300','Figure1_tzvetanov.png')




