%
% data from Figure 1 in Tadin & Lappin 2005
% 

clear all;

a = reshape( load('data_tadinlappin.txt'), [8,4,2] );

size = a(:,:,1);
dur_thr = a(:,:,2);
contr = repmat( [0.09,0.2,0.42,0.92], [8,1] );

figure(1); clf; fs = 22; lw=2; ms=14;
ii=1; loglog( size(:,ii), dur_thr(:,ii), 'kd', 'markerfacecolor', 'w', 'markersize', ms, 'linewidth', lw )
hold on;
ii=2; loglog( size(:,ii), dur_thr(:,ii), 'kd', 'markerfacecolor', 'k', 'markersize', ms, 'linewidth', lw )
ii=3; loglog( size(:,ii), dur_thr(:,ii), 'ko', 'markerfacecolor', 'w', 'markersize', ms, 'linewidth', lw )
ii=4; loglog( size(:,ii), dur_thr(:,ii), 'ko', 'markerfacecolor', 'k', 'markersize', ms, 'linewidth', lw )
hold off;
set(gca,'fontsize',fs);
axis([0.2,10,10,300]); axis square; box off;
xlabel('Stimulus size (deg.)')
ylabel('Duration Threshold (ms)')
hl=legend({'c=9%';'c=20%';'c=42%';'c=92%'},'location','north');
set(hl,'fontsize',fs,'box','off')

% fitting

options = optimset('Display', 'off', 'TolFun',1e-12, 'TolX', 1e-12, ...
  'MaxIter', 50000, 'MaxFunEvals', 50000 );

% Model_Tzvetan_c50_DurThresh( c, s, p=[Cdec, t50, ai, se, si, c50e, c50i, pe, cs] )
model = @(c,s,p) Model_TadinLAppin_c50_DurThresh( c, s, p );
pinim = [5/100, 200, 0.5, 2, 5, 0.05, 0.3, 1.5, 10, 0.4 ];

funcML = @(p) ssqTL_c50( contr(:), size(:), dur_thr(:), model, p );

ml0=1e6;
for ii=1:100
  pini = ( 0.5 + rand( 1, numel(pinim) ) ) .* pinim;
  [ pp, ml ] = fminsearch( funcML, pini, options );
  fprintf( ' i fit %3d ml: %.4f, pars:', ii, ml );
  if ml < ml0, ml0=ml; pf=pp; fprintf(' %.5f', pf); end
  fprintf('\n');
end

sizeth = repmat( (0.25:0.05:6.5)', [1,4] );
contrth = repmat( [0.09,0.2,0.42,0.92], [numel(sizeth(:,1)),1] );
thr_model=[]; thr_model = model( contrth, sizeth, pf );

hold on; lt = {'-';'--';'-.';':'};
for ii=1:4, loglog( sizeth(:,1), thr_model(:,ii), ['k' lt{ii}], 'linewidth', lw ); end
hold off;

return;

save('model_fit_TadinLappin2005.mat','pf','ml0');

orient landscape
print('-dpdf','data_tadinlappin_fig1_model.pdf')
print('-dpng','-r300','data_tadinlappin_fig1_model.png')




