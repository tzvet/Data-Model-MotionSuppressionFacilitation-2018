function t_thresh = Model_TadinLAppin_c50_DurThresh( c, s, p )
%                      c, s, Cdec, t50, ai, si, se, c12e, c12i, p, m, k )
  %
  % here excitatory amplitude ae of the center spatial tuning is pooled in Cdec
  % and Rinh 
  %
  
  Cdec = p(1);
  t50 = p(2);
  ai = p(3);
  se = p(4);
  si = p(5);
  c12e = p(6);
  c12i = p(7);
  pe = p(8);
  m = p(9);
  k = p(10);

  pi = pe;
  n=1;
  
  Rexc = ( c.^pe*(1-c12e^pe) ./ ( c.^pe*(1-2*c12e^pe) + c12e.^pe ) ) .* ( erf( s ./ (se./(1+m*exp(-k./c)) ) ) );
  Rinh = ( c.^pi*(1-c12i^pi) ./ ( c.^pi*(1-2*c12i^pi) + c12i.^pi ) ) .* ( ai * erf( s/si ) );
  t_thresh = t50 * ( Cdec ./ ( Rexc - Rinh - Cdec ) ).^(1/n);

  t_thresh( Rexc - Rinh - Cdec <= 0 ) = nan;
  
end
