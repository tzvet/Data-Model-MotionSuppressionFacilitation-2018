% analysis correct model predictions of the effects of changing one variable
% of inhibition: ai, c12i, si

clear all;

load pars_fit_Fig1_data_Schallmo_et_al.mat;
load('elife-2018-schallmo-et-al-data-figs-SuppressionFacilitation.mat');

c = [ 0.03, 0.92 ];
s = 0.2:0.05:20;

Cdec = 0.05;
c12e = 0.005;
p = 0.75;
se = 2.5;
m = 7.8;
k = 0.3;

% take the fit values
t50 = pf(1);
ai = pf(2);
si = pf(3);
c12i = pf(4);

%  t_thresh = Model_TadinLAppin_c50_DurThresh( c, s, p );
%  p = [c, s, Cdec, t50, ai, si, se, c50e, c50i, p, m, k )

pars_std = [ Cdec, t50, ai, si, se, c12e, c12i, p, m, k ];
for ii=1:numel(c), thr_std(ii,:) = Model_TadinLAppin_c50_DurThresh( c(ii), s, pars_std ); end

ai2 = 0.9;
pars_ai = [ Cdec, t50, ai2, si, se, c12e, c12i, p, m, k ];
for ii=1:numel(c), thr_ai(ii,:) = Model_TadinLAppin_c50_DurThresh( c(ii), s, pars_ai ); end

c12i2 = 0.01;
pars_c12i = [ Cdec, t50, ai, si, se, c12e, c12i2, p, m, k ];
for ii=1:numel(c), thr_c12i(ii,:) = Model_TadinLAppin_c50_DurThresh( c(ii), s, pars_c12i ); end

si2 = 3.8;
pars_si = [ Cdec, t50, ai, si2, se, c12e, c12i, p, m, k ];
for ii=1:numel(c), thr_si(ii,:) = Model_TadinLAppin_c50_DurThresh( c(ii), s, pars_si ); end

% PLOTS

x = Fig1.C.x.data;
y1 = Fig1.C.y.cond_1.data;
y1lab = ['c=',Fig1.C.y.cond_1.name(1:3)];
y2 = Fig1.C.y.cond_2.data;
y2lab = ['c=',Fig1.C.y.cond_2.name(1:2)];

figure(1); clf; fs = 20; lw = 2;
plchng = [-0.03,-0.05,0.1,0.1];

subplot(1,2,1)
loglog( x(1,:), mean(y1), 'rs', 'linewidth', lw );
hold on;
loglog( x(1,:), mean(y2), 'bo', 'linewidth', lw );
he=errorbar( x(1,:), mean(y1), std(y1)/sqrt(10), 'rs' ); set(he,'linewidth',lw);
he=errorbar( x(1,:), mean(y2), std(y2)/sqrt(10), 'bo' ); set(he,'linewidth',lw);
sizeth = repmat( (0.8:0.05:20)', [1,2] );
contrth = repmat( [0.98,0.03], [numel(sizeth(:,1)),1] );
thr_model=[]; thr_model = Model_TadinLAppin_c50_DurThresh( contrth, sizeth, pars_std );
ct = {'r';'b'};
for ii=1:2, loglog( sizeth(:,1), thr_model(:,ii), [ct{ii}], 'linewidth', lw ); end
hold off;
set(gca,'fontsize',fs); box off;
set(gca,'position',get(gca,'position')+plchng)
axis([0.8,20,10,200]); axis square;
xlabel('Stimulus diameter (deg.)');
ylabel('Duration threshold (ms)');
hl=legend({y1lab;y2lab},'location','north');
set(hl,'fontsize',fs,'box','off','position',get(hl,'position')+[0,-0.15,0,0]);
text(0.9,190,'A','fontsize',fs+4,'fontweight','bold')

subplot(1,2,2)
loglog( ...
  s, thr_std(1,:), 'b-', 'linewidth', lw, ...
  s, thr_ai(1,:), 'b--', 'linewidth', lw, ...
  s, thr_c12i(1,:), 'b-.', 'linewidth', lw, ...
  s, thr_si(1,:), 'b:', 'linewidth', lw, ...
  s, thr_std(2,:), 'r-', 'linewidth', lw, ...
  s, thr_ai(2,:), 'r--', 'linewidth', lw, ...
  s, thr_c12i(2,:), 'r-.', 'linewidth', lw, ...
  s, thr_si(2,:), 'r:', 'linewidth', lw ...
  )
set(gca,'fontsize',fs,'yticklabel',[]); box off;
set(gca,'position',get(gca,'position')+plchng)
axis([0.8,20,10,200]); axis square;
xlabel('Stimulus diameter (deg.)');
%ylabel('Duration threshold (ms)');
hl=legend({'data fit';sprintf('a_i=%.2f',ai2);...
  [sprintf('c_{1/2,i}=%.1f',c12i2*100),'%'];...
  ['\sigma_i=',sprintf('%.1f',si2)]},'location','southeast');
set(hl,'fontsize',fs-4,'box','off','position',get(hl,'position')+[0,0.18,0,0]);
text(0.9,190,'B','fontsize',fs+4,'fontweight','bold')
  

return;

orient landscape
print('-dpng','-r300','Data_model_schallmo_Fig1_predict_Inhibition.png');
print('-dpdf','Data_model_schallmo_Fig1_predict_Inhibition.pdf');












