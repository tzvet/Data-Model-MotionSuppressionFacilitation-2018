This file contains the data for the manuscript entitled:
"Suppression and facilitation of human neural responses"

Authors: Schallmo, M-P., Kale, A.M., Millin, R., Flevaris, A.V., 
Brkanac, Z., Edden, R.A.E., Bernier, R.A., Murray, S.O.

Upload date: 2017/08/18

Contact: Schallmo, M-P.
Email: schallmo_at_uw_dot_edu

Data are stored within a single MATLAB (The Mathworks, Natick, MA, USA) data file
(.mat format), and organized into variables according to the associated figure
(e.g., Fig2, SupFig4, etc.)

Each figure variable is a structure that contains fields for each relevant sub-panel
(e.g., Fig5.A)

Each panel field is a structure that contains the fields: x, y, dimension_key
x - contains x-axis data & labels
y - contains y-axis data & labels - If more than one type of data are plotted on the 
    same panel with the same x values, then there will be multiple y.data fields 
    (e.g., Fig4.A.y.lorazepam_data, Fig4.A.y.placebo_data) 
    OR the y.data field will be sub-divided into multiple cells 
    (e.g., SupFig1.B.y.data{1,1})
dimension_key - A string explaining how the data in the x & y structures are organized
    (e.g., SupFig1.B.dimension_key = '10 subjects x 9 TRs (2 sec each)' )
