%

clear all;

load('elife-2018-schallmo-et-al-data-figs-SuppressionFacilitation.mat');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIGURE 1
%

x = Fig1.C.x.data;
y1 = Fig1.C.y.cond_1.data;
y1lab = Fig1.C.y.cond_1.name;
y2 = Fig1.C.y.cond_2.data;
y2lab = Fig1.C.y.cond_2.name;

figure(1); clf; fs = 20; lw = 2;
loglog( x(1,:), mean(y1), 'rs', 'linewidth', lw );
hold on;
loglog( x(1,:), mean(y2), 'bo', 'linewidth', lw );
he=errorbar( x(1,:), mean(y1), std(y1)/sqrt(10), 'rs' ); set(he,'linewidth',lw);
he=errorbar( x(1,:), mean(y2), std(y2)/sqrt(10), 'bo' ); set(he,'linewidth',lw);
hold off;
set(gca,'fontsize',fs); box off;
axis([0.8,20,10,200]); axis square;
xlabel('Stimulus diameter (deg.)');
ylabel('Duration threshold (ms)');
hl=legend({y1lab;y2lab},'location','north');
set(hl,'fontsize',fs,'box','off');

% fitting + plot
options = optimset('Display', 'off', 'TolFun',1e-12, 'TolX', 1e-12, ...
                   'MaxIter', 30000, 'MaxFunEvals', 30000 );
model = @(c,s,p) Model_TadinLAppin_c50_DurThresh_3pars( c, s, p );
pinim = [100, 0.5, 5, 0.3 ];
xx=x(1:2,:); yy=[mean(y1);mean(y2)];
funcML = @(p) ssqTL_c50( repmat([0.98;0.03],[1,3]), xx(:), yy(:), model, p );

ml0=1e6;
for ii=1:50
  pini = ( 0.5 + rand( 1, numel(pinim) ) ) .* pinim;
  [ pp, ml ] = fminsearch( funcML, pini, options );
  fprintf( ' i fit %3d ml: %.8f\n', ii, ml );
  if ml < ml0, ml0=ml; pf=pp; end
end
disp([ml0,pf])
sizeth = repmat( (0.8:0.05:20)', [1,2] );
contrth = repmat( [0.98,0.03], [numel(sizeth(:,1)),1] );
thr_model=[]; thr_model = model( contrth, sizeth, pf );

hold on; ct = {'r';'b'};
for ii=1:2, loglog( sizeth(:,1), thr_model(:,ii), [ct{ii}], 'linewidth', lw ); end
hold off;


return; % comment this, or copy and paste the 3 lines below to get the files

orient landscape
print('-dpdf','data_Schallmo_et_al_fig1_model.pdf')
print('-dpng','-r300','data_Schallmo_et_al_fig1_model.png')
