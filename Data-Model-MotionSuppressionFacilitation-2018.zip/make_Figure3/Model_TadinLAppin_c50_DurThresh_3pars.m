function t_thresh = Model_TadinLAppin_c50_DurThresh_3pars( c, s, p )
%                      c, s, Cdec, t50, ai, si, se, c50e, c50i, p, m, k )
  %
  % here excitatory amplitude ae of the center spatial tuning is pooled in Cdec
  % and Rinh 
  %
  
  t50 = p(1);
  ai = p(2);
  si = p(3);
  c50i = p(4);
%  pe = p(5);

  Cdec = 0.05;
  se = 2.5;
  c50e = 0.005;
  m = 7.8;
  k = 0.3;
  
  pe = 0.75;
  pi = pe;
  n=1;
  
  Rexc = ( c.^pe*(1-c50e^pe) ./ ( c.^pe*(1-2*c50e^pe) + c50e.^pe ) ) .* ( erf( s ./ (se./(1+m*exp(-k./c)) ) ) );
  Rinh = ( c.^pi*(1-c50i^pi) ./ ( c.^pi*(1-2*c50i^pi) + c50i.^pi ) ) .* ( ai * erf( s/si ) );
  t_thresh = t50 * ( Cdec ./ ( Rexc - Rinh - Cdec ) ).^(1/n);

  t_thresh( Rexc - Rinh - Cdec <= 0 ) = nan;
  
end
