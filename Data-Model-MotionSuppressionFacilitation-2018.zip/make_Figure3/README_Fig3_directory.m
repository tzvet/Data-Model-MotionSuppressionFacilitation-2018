% This directory contains all data and scripts that allow to reproduce Figure 3
% of the manuscript.
%
% 1. The original data posted by Schallmo et al. (2018)
% Schallmo M, Kale AM, Millin R, Flevaris AV, Brkanac Z, Edden RAE, Bernier RA,
% Murray S (2018) Data from: Suppression and facilitation of human neural
% responses. Dryad Digital Repository. https://doi.org/10.5061/dryad.rv71c
%    "elife-2018-schallmo-et-al-data-figs-SuppressionFacilitation.mat"
%    "elife-2018-schallmo-et-al-README.txt"
%    See https://elifesciences.org/articles/30334/figures, "Data availability"
% 2. The scripts for the model developed in the manuscript
%    a. "fit_plot_data_schallmoetal.m" - for fitting Schallmo et al.'s data
%    b. "predict_model_change_inhib_pars.m" - make Figure 3A,B
%