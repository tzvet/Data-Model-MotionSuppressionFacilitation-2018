function ml = ssqTL_c50( contr, size, dur_thr, model, p )
  
  thrmodel = model( contr(:), size(:), p );
  
  ml = sum( ( log10(dur_thr(:)) - log10(thrmodel) ).^2 );
%  ml = sum( ( (dur_thr(:)) - (thrmodel) ).^2 );
  
  if sum(p<0)>0, ml=1e6; end
  if isinf(ml), ml = 1e6; end
  if isnan(ml), ml = 1e6; end
end
