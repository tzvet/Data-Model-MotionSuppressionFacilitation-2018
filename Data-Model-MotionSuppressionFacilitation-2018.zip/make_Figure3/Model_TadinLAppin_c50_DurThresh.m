function t_thresh = Model_TadinLAppin_c50_DurThresh( c, s, p )
%                      c, s, Cdec, t50, ai, si, se, c50e, c50i, p, m, k )
  %
  % here excitatory amplitude ae of the center spatial tuning is pooled in Cdec
  % and Rinh 
  %
  
  Cdec = p(1);
  t50 = p(2);
  ai = p(3);
  si = p(4);
  se = p(5);
  c50e = p(6);
  c50i = p(7);
  pe = p(8);
%  pi = p(9);
  pi = pe;
  m = p(9);
  k = p(10);

  n=1;
  
  Rexc = ( c.^pe*(1-c50e^pe) ./ ( c.^pe*(1-2*c50e^pe) + c50e.^pe ) ) .* ( erf( s ./ (se./(1+m*exp(-k./c)) ) ) );
  Rinh = ( c.^pi*(1-c50i^pi) ./ ( c.^pi*(1-2*c50i^pi) + c50i.^pi ) ) .* ( ai * erf( s/si ) );
  t_thresh = t50 * ( Cdec ./ ( Rexc - Rinh - Cdec ) ).^(1/n);

  t_thresh( Rexc - Rinh - Cdec <= 0 ) = nan;
  
end
